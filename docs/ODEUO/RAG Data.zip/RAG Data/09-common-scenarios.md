# Common Call Scenarios Guide - AI Voice Receptionist

## Executive Summary

This guide provides real-world examples of how the AI voice receptionist handles different types of calls across various practice areas, situations, and caller types. Each scenario includes the complete conversation flow, AI decision-making logic, and outcomes.

**Purpose:** Help law firms understand exactly how the AI will represent their practice and handle the full spectrum of calls they receive.

---

## How to Use This Guide

### Scenario Structure

Each scenario includes:
- **Context:** Call type and situation
- **Caller Profile:** Who's calling and why
- **AI Goals:** What the AI aims to accomplish
- **Conversation:** Full dialogue transcript
- **AI Decision Points:** Why AI made specific choices
- **Outcome:** What happened and next steps
- **Data Captured:** Information gathered

### Call Flow Patterns

```
Answer → Greet → Understand Need → Gather Info → 
Take Action (Book/Transfer/Message) → Confirm → End
```

---

## General Inquiries

### Scenario 1: Basic Practice Area Question

**Context:** Business hours, caller researching attorneys  
**Practice Area:** General  
**Caller Profile:** Potential new client, initial research phase

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. How may I help you today?

**Caller:** Hi, yes, I'm looking for information about what types of cases you handle.

**AI:** I'd be happy to help with that. Smith & Associates focuses on several practice areas including personal injury, family law, estate planning, and criminal defense. Is there a particular type of legal matter you're interested in?

**Caller:** Personal injury. I was in a car accident.

**AI:** I'm sorry to hear about your accident. Our personal injury team handles auto accident cases. Can I ask when the accident occurred?

**Caller:** About two weeks ago.

**AI:** Thank you. Personal injury matters often have important time considerations, so I'd recommend speaking with one of our attorneys soon. Would you like to schedule a free consultation to discuss your case?

**Caller:** Yes, that would be good.

**AI:** Excellent. Before we schedule that, I need to collect some basic information. May I have your name?

**Caller:** John Martinez.

**AI:** Thank you, Mr. Martinez. And what's the best phone number to reach you?

**Caller:** 555-123-4567.

**AI:** Perfect, and do you have an email address?

**Caller:** jmartinez@email.com.

**AI:** Thank you. Now, looking at our calendar, our personal injury attorney has availability this week. Would Thursday at 2 PM work for you, or would you prefer a different time?

**Caller:** Thursday at 2 works.

**AI:** Perfect. I've scheduled a consultation for you with Attorney Williams on Thursday, October 19th at 2:00 PM. This will be at our office at 123 Main Street. You'll receive a confirmation email shortly with directions and information about what to bring. Is there anything else I can help you with today?

**Caller:** No, that's all. Thank you.

**AI:** You're welcome, Mr. Martinez. We look forward to meeting with you on Thursday. Have a great day.

**AI Decision Points:**
- Identified practice area inquiry
- Recognized urgency indicator (recent accident)
- Offered immediate solution (consultation)
- Gathered necessary intake info
- Booked appointment with appropriate attorney
- Confirmed details to prevent no-shows

**Outcome:** 
- Consultation booked
- Lead captured and qualified
- Client satisfied with responsiveness

**Data Captured:**
- Name: John Martinez
- Phone: 555-123-4567
- Email: jmartinez@email.com
- Matter: Personal Injury - Auto Accident
- Incident Date: ~2 weeks ago
- Appointment: Thu Oct 19, 2:00 PM with Attorney Williams

---

### Scenario 2: Fee Structure Question

**Context:** After hours, caller researching costs  
**Practice Area:** Estate Planning  
**Caller Profile:** Cost-conscious potential client

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. How may I help you today?

**Caller:** Hi, I want to know how much it costs to do a will.

**AI:** I'd be happy to provide information about our estate planning services. For a simple will, our fees typically range from $500 to $1,200 depending on the complexity of your estate and specific needs. More complex estate plans involving trusts may range from $2,000 to $5,000. The exact cost would be determined after reviewing your specific situation. Would you like to schedule a consultation to discuss your needs in detail?

**Caller:** That's more than I expected. Do you offer payment plans?

**AI:** Yes, we do offer flexible payment arrangements for estate planning services. The specific terms would be discussed during your consultation with the attorney. They can work with you to create a plan that fits your budget. May I schedule that consultation for you?

**Caller:** Maybe. Can I think about it?

**AI:** Of course. Let me give you our office number so you can call back when you're ready: 555-987-6543. We're open Monday through Friday from 9 AM to 5 PM. Or, if you'd like, I can take your contact information and have someone follow up with you in a few days. Which would you prefer?

**Caller:** You can take my number. I might call back next week.

**AI:** Perfect. May I have your name and phone number?

**Caller:** Sarah Johnson, 555-234-5678.

**AI:** Thank you, Ms. Johnson. I'll make a note that you're interested in estate planning services. Someone from our office will give you a call early next week to answer any other questions you might have. Is there anything else I can help you with this evening?

**Caller:** No, that's all.

**AI:** Thank you for calling Smith & Associates. Have a great evening, Ms. Johnson.

**AI Decision Points:**
- Provided specific price ranges (per approved guidelines)
- Addressed cost objection with payment plan option
- Didn't push too hard when caller hesitant
- Offered both self-service and follow-up options
- Captured lead information for follow-up
- Professional closure maintaining good impression

**Outcome:**
- Lead captured for follow-up
- Price objection handled professionally
- Relationship maintained for future contact

**Data Captured:**
- Name: Sarah Johnson
- Phone: 555-234-5678
- Matter: Estate Planning - Will
- Status: Considering, cost-sensitive
- Follow-up: Requested for next week

---

## Practice Area-Specific Scenarios

### Personal Injury

#### Scenario 3: Recent Car Accident (Urgent)

**Context:** After hours, recent accident  
**Caller Profile:** Injured, needs immediate help

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. How may I help you today?

**Caller:** Hi, I was just in a car accident this afternoon and I don't know what to do.

**AI:** I'm very sorry to hear you were in an accident. First, are you injured? Do you need medical attention right now?

**Caller:** No, I'm okay. I went to urgent care and they said I'm fine, just sore. But the other driver's insurance is already calling me and I'm not sure if I should talk to them.

**AI:** I understand. It's important that you speak with an attorney before giving any recorded statements to insurance companies. Our personal injury attorneys can guide you through this process. Let me get some basic information and connect you with one of our attorneys as soon as possible. May I have your name?

**Caller:** David Chen.

**AI:** Thank you, Mr. Chen. And your phone number?

**Caller:** 555-876-5432.

**AI:** Perfect. Can you tell me briefly what happened in the accident?

**Caller:** I was stopped at a red light and someone rear-ended me. Pretty hard impact.

**AI:** I'm sorry that happened. Were there any witnesses, and did the police come to the scene?

**Caller:** Yes, police came and made a report. I got the report number.

**AI:** Excellent, that's helpful. Now, you mentioned the other driver's insurance is calling. Have you already spoken with them or given any statements?

**Caller:** No, they just left a voicemail asking me to call them back.

**AI:** Good. I'd recommend not calling them back until you've spoken with one of our attorneys. Let me see what I can do to get you connected quickly. Since this just happened today, I'm going to mark this as urgent. Our office opens at 9 AM tomorrow morning, and I'm going to have Attorney Williams call you first thing. Would 9:15 AM work for you?

**Caller:** Yes, that would be great.

**AI:** Perfect. You'll receive a call from Attorney Williams at 9:15 AM tomorrow at 555-876-5432. In the meantime, here are a few important things: Don't give any recorded statements to any insurance company. Take photos of your vehicle damage if you haven't already. Keep all medical records and receipts. And if you have any urgent questions before tomorrow morning, you can call our after-hours emergency line at 555-999-1234. Do you have any other questions right now?

**Caller:** No, I think that covers it. Thank you so much.

**AI:** You're very welcome, Mr. Chen. Attorney Williams will call you at 9:15 AM tomorrow. Take care and feel better.

**AI Decision Points:**
- Immediately assessed for emergency medical needs
- Recognized urgent timing (recent accident, insurance calling)
- Provided critical advice (don't talk to insurance)
- Captured key facts quickly
- Escalated to attorney callback (not just scheduled consultation)
- Provided clear next steps and protection guidance
- Offered emergency contact option

**Outcome:**
- Urgent case flagged for attorney
- Client protected from insurance statement
- Morning callback scheduled
- Potential case secured

**Data Captured:**
- Name: David Chen
- Phone: 555-876-5432
- Incident: Rear-ended at red light, today
- Injury: Minor, saw urgent care
- Police report: Yes, has report number
- Insurance: Other party's insurance calling, no statement given yet
- Urgency: HIGH - Attorney callback 9:15 AM tomorrow

---

#### Scenario 4: Old Injury, Statute of Limitations Concern

**Context:** Business hours  
**Caller Profile:** Person with older injury, may be time-barred

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. How may I help you today?

**Caller:** I was in an accident a while back and I'm wondering if I can still file a claim.

**AI:** I see. May I ask when the accident occurred?

**Caller:** It was about two and a half years ago.

**AI:** Thank you for that information. Personal injury cases do have time limits, called statutes of limitations, which vary by state and type of case. In our state, most personal injury claims have a two-year statute of limitations, though there can be exceptions. Given that your accident was two and a half years ago, this is something you should discuss with an attorney immediately as time may be running out. Are you available to speak with one of our attorneys today?

**Caller:** I'm at work right now.

**AI:** I understand. This is time-sensitive, so I'd recommend scheduling a consultation as soon as possible - ideally today or tomorrow if possible. Looking at our schedule, we have an opening at 4:30 PM today, or tomorrow morning at 9 AM. Would either of those work?

**Caller:** I could probably do 4:30 today.

**AI:** Excellent. Let me get your information and get this scheduled. Your name?

**Caller:** Maria Gonzalez.

**AI:** Thank you, Ms. Gonzalez. Phone number?

**Caller:** 555-345-6789.

**AI:** Perfect. And just to confirm, the accident was approximately two and a half years ago. What type of accident was it?

**Caller:** Car accident. The other driver ran a stop sign.

**AI:** I've scheduled you for a consultation with Attorney Williams today at 4:30 PM at our office. Given the time sensitivity, I'm also going to flag this as urgent so the attorney is aware of the potential statute of limitations issue. You'll receive a confirmation email, and please bring any documents you have about the accident - police report, medical records, insurance correspondence, anything like that. Is there anything else I can help you with?

**Caller:** No, thank you.

**AI:** Thank you for calling, Ms. Gonzalez. We'll see you at 4:30 PM today.

**AI Decision Points:**
- Immediately identified potential statute of limitations issue
- Conveyed urgency without providing legal advice
- Pushed for same-day appointment due to time sensitivity
- Flagged case as urgent for attorney attention
- Provided clear instructions about documents
- Did NOT say "you can't file" (that's legal advice)

**Outcome:**
- Same-day consultation scheduled
- Attorney alerted to time-sensitive issue
- Can still evaluate if exceptions apply

**Data Captured:**
- Name: Maria Gonzalez
- Phone: 555-345-6789
- Incident: Car accident, ~2.5 years ago, other driver ran stop sign
- Urgency: HIGH - Potential SOL issue
- Appointment: Today 4:30 PM (expedited)
- Flag: URGENT - Statute of limitations concern

---

### Family Law

#### Scenario 5: Emotional Divorce Inquiry

**Context:** After hours  
**Caller Profile:** Emotional, going through difficult situation

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. How may I help you today?

**Caller:** [voice shaking] Hi, I... I think I need a divorce lawyer.

**AI:** I understand this is a difficult time. I'm here to help. Smith & Associates has experienced family law attorneys who can guide you through this process. May I ask your name?

**Caller:** Jennifer... Jennifer Adams.

**AI:** Thank you, Jennifer. I can hear this is emotional for you, and that's completely understandable. Take your time. When you're ready, can you tell me a bit about your situation?

**Caller:** [crying] I just found out my husband has been having an affair. We have two kids and I don't know what to do.

**AI:** I'm so sorry you're going through this. Our family law attorneys work with clients in situations like yours regularly, and they can help you understand your options for both the divorce and custody matters. Can I ask, do you feel safe at home right now?

**Caller:** Yes, he's not home right now. He doesn't know I'm calling.

**AI:** Okay. If you ever don't feel safe, please call 911 immediately. Now, I'd like to connect you with one of our family law attorneys who can discuss your situation in detail and explain your rights and options. They can also advise you on immediate steps you might want to take. Would you prefer to come into our office for a consultation, or would a phone consultation be better given your circumstances?

**Caller:** I think I'd rather come in. I don't want to talk about this at home.

**AI:** That makes sense. Let me check our calendar for you. We have availability tomorrow at 10 AM, or Thursday at 2 PM, or Friday morning at 9 AM. Which works best?

**Caller:** Tomorrow at 10 would work. My kids will be at school.

**AI:** I've scheduled you for tomorrow at 10 AM with Attorney Rodriguez, who specializes in family law. Do you have a pen handy? I want to give you the office address.

**Caller:** Yes, hold on... okay.

**AI:** Our office is at 123 Main Street, Suite 200. There's parking in the garage underneath the building. Your appointment is at 10 AM tomorrow, October 18th. You'll receive a confirmation email at... do you have an email address?

**Caller:** Yes, it's jadams@email.com.

**AI:** Perfect. I've sent a confirmation there. Now, Jennifer, is there anything else I can help you with this evening?

**Caller:** No, thank you. I appreciate you being so kind.

**AI:** Of course. You're taking the right step by seeking legal advice. Attorney Rodriguez will be able to answer all your questions tomorrow. Take care of yourself this evening.

**AI Decision Points:**
- Recognized emotional distress and adjusted tone accordingly
- Showed empathy while remaining professional
- Assessed for safety concerns (domestic violence screening)
- Offered consultation options considering circumstances
- Provided practical details (kids at school timing)
- Maintained supportive but professional demeanor
- Did not provide legal advice about divorce or custody

**Outcome:**
- Consultation booked at sensitive time (kids at school)
- Client felt heard and supported
- Safety screening completed
- Connection with appropriate specialist attorney

**Data Captured:**
- Name: Jennifer Adams
- Email: jadams@email.com
- Matter: Divorce - marital affair disclosed, 2 children
- Safety: No immediate concerns, husband not home
- Emotional state: Distressed, needs support
- Appointment: Tomorrow 10 AM with Attorney Rodriguez (family law specialist)
- Privacy: Prefers office meeting, concerned about discussing at home

---

#### Scenario 6: Child Custody Modification

**Context:** Business hours  
**Caller Profile:** Existing custody order, seeking modification

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. How may I help you today?

**Caller:** I need help modifying a custody agreement.

**AI:** I can help you with that. Our family law attorneys handle custody modifications. May I ask a few questions to better understand your situation?

**Caller:** Sure.

**AI:** First, your name?

**Caller:** Robert Taylor.

**AI:** Thank you, Mr. Taylor. Do you currently have a custody order in place?

**Caller:** Yes, we've had one for about three years. My ex-wife and I share custody 50/50, but she just got a new job and wants to move three hours away with the kids.

**AI:** I understand. That's a significant change that would affect the current arrangement. Do you have children together?

**Caller:** Two kids, ages 8 and 10.

**AI:** Thank you. And has your ex-wife already relocated, or is she planning to?

**Caller:** She's planning to. She wants to move next month.

**AI:** This is something you'll want to address quickly. Typically, a parent can't relocate with children beyond a certain distance without either the other parent's agreement or court approval. An attorney can advise you on your rights and options. How soon are you able to meet for a consultation?

**Caller:** As soon as possible. Today if you have anything.

**AI:** Let me check our family law attorney's schedule... Yes, Attorney Rodriguez has an opening this afternoon at 3 PM. Would that work?

**Caller:** Perfect.

**AI:** Great. I'll need a few more pieces of information. Your phone number?

**Caller:** 555-567-8901.

**AI:** And email address?

**Caller:** rtaylor@email.com.

**AI:** Excellent. I've scheduled you for today at 3 PM with Attorney Rodriguez. Please bring a copy of your current custody order if you have it, and any communication you've had with your ex-wife about the proposed move. The office is located at 123 Main Street, Suite 200. Is there anything else I can help you with?

**Caller:** No, that covers it. Thank you.

**AI:** You're welcome, Mr. Taylor. We'll see you at 3 PM today.

**AI Decision Points:**
- Identified time-sensitive custody matter
- Gathered key facts (existing order, relocation, timeline)
- Recognized urgency and offered same-day appointment
- Provided general information about relocation requirements without legal advice
- Instructed client to bring relevant documents
- Professional and efficient handling

**Outcome:**
- Same-day consultation scheduled
- Urgent matter flagged
- Client prepared with documents

**Data Captured:**
- Name: Robert Taylor
- Phone: 555-567-8901
- Email: rtaylor@email.com
- Matter: Custody modification - ex-wife proposed relocation
- Children: 2 (ages 8 and 10)
- Current custody: 50/50 shared custody for 3 years
- Urgency: Proposed move in 30 days
- Appointment: Today 3 PM with Attorney Rodriguez

---

### Criminal Defense

#### Scenario 7: Recent Arrest (Urgent)

**Context:** Late evening, after hours  
**Caller Profile:** Family member of arrested person, highly urgent

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. How may I help you today?

**Caller:** My son was just arrested and I need a lawyer right away!

**AI:** I understand this is urgent. I'm going to help you. First, is your son still in custody?

**Caller:** Yes, he's at the county jail right now.

**AI:** Okay. Do you know what the charges are?

**Caller:** They said DUI and something about resisting arrest, but I don't have all the details.

**AI:** When was he arrested?

**Caller:** Tonight, about two hours ago.

**AI:** I understand. Let me get your information and make sure our criminal defense attorney gets this message immediately. Your name?

**Caller:** Margaret Foster.

**AI:** Thank you, Ms. Foster. And your phone number?

**Caller:** 555-678-9012.

**AI:** Your son's name?

**Caller:** Michael Foster.

**AI:** Thank you. Now, Ms. Foster, because this is an arrest situation, I'm going to have our criminal defense attorney, Attorney Jackson, call you back within the hour. He handles these matters and can advise you on immediate steps. In the meantime, here's what I need you to know: Don't have your son make any statements to police without an attorney present. If he hasn't been arraigned yet, that will likely happen tomorrow morning, and having an attorney there is important. Do you understand?

**Caller:** Yes, yes. When will the attorney call me?

**AI:** Attorney Jackson will call you within the hour at 555-678-9012. If you don't hear from him within an hour, please call our emergency line at 555-999-1234. Do you have any other immediate questions?

**Caller:** No, I just need the attorney to call soon.

**AI:** He will call you very soon. Stay by your phone. Try to remain calm - Attorney Jackson will guide you through the next steps.

**Caller:** Thank you.

**AI:** You're welcome, Ms. Foster. Attorney Jackson will be calling you shortly.

**[AI immediately sends urgent notification to Attorney Jackson via SMS, email, and phone call]**

**AI Decision Points:**
- Immediately recognized criminal emergency
- Gathered critical facts quickly (custody status, charges, timing)
- Did NOT schedule a consultation (too urgent)
- Escalated to immediate attorney callback
- Provided critical advice (don't make statements)
- Explained arraignment process briefly
- Provided emergency backup number
- Sent multi-channel urgent alert to attorney

**Outcome:**
- Attorney alerted immediately to handle urgent criminal matter
- Family provided with critical guidance
- Client protected from self-incrimination
- Attorney can respond immediately to custody/arraignment situation

**Data Captured:**
- Contact: Margaret Foster (mother)
- Phone: 555-678-9012
- Defendant: Michael Foster (son)
- Charges: DUI + Resisting arrest
- Status: In custody at county jail
- Timing: Arrested 2 hours ago
- Urgency: CRITICAL - Attorney callback within 1 hour
- Note: Likely arraignment tomorrow morning

---

### Estate Planning

#### Scenario 8: Simple Will Inquiry

**Context:** Business hours  
**Caller Profile:** Senior citizen, planning ahead

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. How may I help you today?

**Caller:** Hello, I'm calling about getting a will made.

**AI:** I'd be happy to help you with that. Our estate planning attorneys can prepare wills and other estate planning documents. May I ask your name?

**Caller:** Helen Richardson.

**AI:** Thank you, Ms. Richardson. To help our attorney prepare for your consultation, can I ask a few general questions about your estate planning needs?

**Caller:** Sure.

**AI:** Do you currently have a will in place, or would this be creating a new one?

**Caller:** I've never had one. My husband passed away last year and I realize I should have something in place.

**AI:** I'm sorry for your loss. It's wise to get your estate plan in order. Do you have children?

**Caller:** Yes, two daughters.

**AI:** And do you have any significant assets you'd like to address in your estate plan? For example, real estate, investment accounts, or a business?

**Caller:** I have my house and some savings, but nothing too complicated. I just want to make sure my daughters get everything equally and don't have to fight over anything.

**AI:** That makes perfect sense. A will can definitely accomplish that. Our estate planning attorney can also discuss whether you might benefit from other documents like a power of attorney or healthcare directive. Would you be interested in learning about those as well?

**Caller:** Yes, I think so. I've heard about those.

**AI:** Wonderful. Let me schedule a consultation for you with Attorney Martinez, who specializes in estate planning. The initial consultation is $250 for one hour, and we can typically prepare a simple will package starting around $800, though the exact cost depends on your specific needs. Does that sound reasonable?

**Caller:** Yes, that's fine.

**AI:** Perfect. Looking at our calendar, we have availability next week. Would Tuesday at 10 AM or Thursday at 2 PM work better for you?

**Caller:** Tuesday at 10 would be good.

**AI:** Excellent. May I have your phone number and email address?

**Caller:** My phone is 555-789-0123. I don't use email much, so just the phone is fine.

**AI:** No problem. I've scheduled you for Tuesday, October 24th at 10 AM with Attorney Martinez for estate planning. The office is located at 123 Main Street, Suite 200. We're on the second floor and there's an elevator. You'll receive a reminder call the day before. If you think of any questions before then, feel free to call back. Is there anything else I can help you with today?

**Caller:** No, that's perfect. Thank you so much.

**AI:** You're very welcome, Ms. Richardson. We look forward to meeting you on Tuesday. Have a wonderful day.

**AI Decision Points:**
- Recognized straightforward estate planning need
- Asked qualifying questions professionally
- Suggested complementary services (POA, healthcare directive)
- Provided clear pricing upfront
- Showed sensitivity to recent loss
- Accommodated preference for phone over email
- Mentioned practical details (elevator) for senior client
- Professional and warm tone appropriate for elderly client

**Outcome:**
- Consultation scheduled
- Clear expectations set on pricing
- Client comfortable and informed

**Data Captured:**
- Name: Helen Richardson
- Phone: 555-789-0123 (no email)
- Matter: Estate planning - simple will
- Background: Husband passed away last year, no current will
- Assets: House + savings (not complex)
- Beneficiaries: 2 daughters (equal distribution)
- Additional needs: POA and healthcare directive discussion
- Appointment: Tuesday Oct 24, 10 AM with Attorney Martinez
- Note: Senior citizen, prefers phone contact

---

## Complex Scenarios

### Scenario 9: Caller Wants Immediate Legal Advice

**Context:** Any time  
**Caller Profile:** Demanding, wants answers now

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. How may I help you today?

**Caller:** Yeah, I need to know if I have a case. I was fired from my job last week and I think it was illegal.

**AI:** I understand you're concerned about your employment situation. I'd be happy to connect you with one of our employment law attorneys who can evaluate whether you have a case. Can I schedule a consultation for you?

**Caller:** No, I just need to know yes or no - do I have a case or not?

**AI:** I appreciate that you'd like an immediate answer, but I'm not able to provide legal advice. Every employment situation is different and depends on many specific facts. Our attorney would need to review the details of your situation, your employment contract if you had one, the reasons given for termination, and other factors. What I can do is schedule you for a consultation where an attorney can properly evaluate your case. Would you like me to do that?

**Caller:** This is ridiculous. You can't just tell me if I have a case?

**AI:** I understand your frustration, but providing legal advice requires a thorough review by a licensed attorney. What I can tell you is that our attorneys handle employment law matters including wrongful termination, and they can give you a professional assessment. The initial consultation is $250 for one hour, and during that time the attorney can tell you whether they believe you have a case worth pursuing. Would you like to schedule that?

**Caller:** Fine. When can I come in?

**AI:** Let me check our employment law attorney's availability. May I have your name first?

**Caller:** Tom Bradley.

**AI:** Thank you, Mr. Bradley. We have openings tomorrow at 11 AM or Friday at 3 PM. Which works better?

**Caller:** Tomorrow at 11.

**AI:** Perfect. May I have your phone number?

**Caller:** 555-890-1234.

**AI:** Thank you. I've scheduled you for tomorrow at 11 AM with Attorney Davis who handles employment law. Please bring any documentation you have - termination letter, employment contract, employee handbook, anything related to your termination. The office is at 123 Main Street. Is there anything else I can help you with?

**Caller:** No.

**AI:** Thank you for calling, Mr. Bradley. We'll see you tomorrow at 11 AM.

**AI Decision Points:**
- Firmly but professionally declined to provide legal advice
- Explained WHY legal advice can't be given over the phone
- Offered the appropriate solution (consultation)
- Remained professional despite caller's frustration
- Redirected to proper channel multiple times
- Didn't become defensive or argumentative
- Successfully converted difficult caller into scheduled consultation

**Outcome:**
- Consultation scheduled despite initial resistance
- Maintained professional boundaries
- Protected firm from liability of improper advice

**Data Captured:**
- Name: Tom Bradley
- Phone: 555-890-1234
- Matter: Employment law - potential wrongful termination
- Timing: Fired last week
- Caller tone: Demanding, frustrated
- Appointment: Tomorrow 11 AM with Attorney Davis

---

### Scenario 10: Spanish-Speaking Caller

**Context:** After hours  
**Caller Profile:** Spanish-speaking, limited English

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. How may I help you today?

**Caller:** Um... habla español?

**AI:** Sí, hablo español. ¿En qué puedo ayudarle?
[Yes, I speak Spanish. How can I help you?]

**Caller:** Ah, gracias. Necesito ayuda. Tuve un accidente de auto.
[Thank you. I need help. I had a car accident.]

**AI:** Entiendo. Lamento escuchar sobre su accidente. ¿Cuándo ocurrió el accidente?
[I understand. I'm sorry to hear about your accident. When did the accident happen?]

**Caller:** Hace dos días. El otro conductor me chocó por detrás.
[Two days ago. The other driver hit me from behind.]

**AI:** ¿Resultó lesionado?
[Were you injured?]

**Caller:** Sí, me duele el cuello y la espalda. Fui al hospital.
[Yes, my neck and back hurt. I went to the hospital.]

**AI:** Es importante que hable con uno de nuestros abogados pronto. ¿Me permite recopilar su información para programar una consulta?
[It's important that you speak with one of our attorneys soon. May I collect your information to schedule a consultation?]

**Caller:** Sí, por favor.
[Yes, please.]

**AI:** ¿Cuál es su nombre?
[What is your name?]

**Caller:** Carlos Hernández.

**AI:** Gracias, Sr. Hernández. ¿Su número de teléfono?
[Thank you, Mr. Hernández. Your phone number?]

**Caller:** 555-901-2345.

**AI:** Perfecto. Tenemos un abogado que habla español. ¿Puede venir a la oficina el jueves a las 2 de la tarde?
[Perfect. We have an attorney who speaks Spanish. Can you come to the office Thursday at 2 PM?]

**Caller:** Sí, eso funciona.
[Yes, that works.]

**AI:** Excelente. Su consulta es el jueves 19 de octubre a las 2:00 PM con el Abogado Williams, quien habla español. La oficina está en 123 Main Street, Suite 200. ¿Tiene correo electrónico para enviarle una confirmación?
[Excellent. Your consultation is Thursday, October 19 at 2:00 PM with Attorney Williams, who speaks Spanish. The office is at 123 Main Street, Suite 200. Do you have an email to send you a confirmation?]

**Caller:** Sí, carlosh@email.com.

**AI:** Perfecto. Le enviaré la confirmación con toda la información. ¿Hay algo más en lo que pueda ayudarle esta noche?
[Perfect. I'll send you the confirmation with all the information. Is there anything else I can help you with tonight?]

**Caller:** No, muchas gracias por su ayuda.
[No, thank you very much for your help.]

**AI:** De nada, Sr. Hernández. Que tenga buena noche.
[You're welcome, Mr. Hernández. Have a good evening.]

**AI Decision Points:**
- Detected Spanish language preference immediately
- Switched to Spanish fluently
- Conducted entire conversation in Spanish
- Ensured Spanish-speaking attorney assigned
- Maintained professional legal intake in Spanish
- Made caller comfortable in their language

**Outcome:**
- Spanish-speaking client successfully helped
- Appropriate Spanish-speaking attorney assigned
- Client satisfaction through language accessibility

**Data Captured:**
- Name: Carlos Hernández
- Phone: 555-901-2345
- Email: carlosh@email.com
- Matter: Personal Injury - Rear-end collision
- Injury: Neck and back pain, hospital visit
- Incident: 2 days ago
- Language: Spanish (primary)
- Appointment: Thursday Oct 19, 2 PM with Spanish-speaking Attorney Williams

---

### Scenario 11: Angry Caller / Complaint

**Context:** Business hours  
**Caller Profile:** Upset about previous interaction

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. How may I help you today?

**Caller:** Yeah, I'm calling because I was supposed to get a call back from someone yesterday and no one called me!

**AI:** I apologize for that frustration. Let me help you. May I have your name so I can look into this?

**Caller:** Rachel Stevens. I called Monday about a bankruptcy case and someone said an attorney would call me back within 24 hours. It's been two days!

**AI:** I'm very sorry about that, Ms. Stevens. That's not the level of service we aim to provide. Let me check our system right now to see what happened with your message.

[Pause]

**AI:** I see your message from Monday in our system regarding bankruptcy. I apologize that you didn't receive the callback as promised. Let me make sure this gets addressed immediately. Would you be able to come in for a consultation today or tomorrow, or would you prefer that an attorney call you right away?

**Caller:** At this point I'd rather just come in and talk to someone in person.

**AI:** I completely understand. Let me get you scheduled as soon as possible. We have availability this afternoon at 3:30 PM, or tomorrow morning at 9 AM. Which would work better for you?

**Caller:** This afternoon would be fine.

**AI:** I've scheduled you for today at 3:30 PM with Attorney Parker who handles bankruptcy cases. And Ms. Stevens, I'm going to make sure our office manager is aware of what happened so we can prevent this from happening again. I know your time is valuable and I apologize again for the missed callback.

**Caller:** [calming down] Okay, thank you.

**AI:** Your appointment is at 3:30 PM today at our office, 123 Main Street, Suite 200. Is the phone number we have on file still the best way to reach you - ending in 2345?

**Caller:** Yes, that's correct.

**AI:** Perfect. You'll receive a confirmation, and I'll make a note that this is a priority appointment given the delay. Is there anything else I can help you with?

**Caller:** No, that's fine.

**AI:** Thank you for your patience, Ms. Stevens. We'll see you at 3:30 PM today.

**AI Decision Points:**
- Acknowledged frustration immediately
- Apologized sincerely without becoming defensive
- Took ownership of the problem
- Investigated the issue while caller on the line
- Offered immediate solutions
- Escalated to same-day appointment
- Noted issue for management review
- Turned negative situation into resolution
- Confirmed existing information to prevent another miss

**Outcome:**
- Angry caller converted to scheduled consultation
- Problem addressed professionally
- Management notified for follow-up
- Client relationship potentially saved

**Data Captured:**
- Name: Rachel Stevens
- Phone: ***-***-2345 (confirmed)
- Matter: Bankruptcy
- Issue: Missed callback from Monday (service failure)
- Status: Initially upset, resolved with same-day appointment
- Appointment: Today 3:30 PM with Attorney Parker (priority)
- Note: Management should follow up on missed callback

---

### Scenario 12: Competitor Research Call

**Context:** Business hours  
**Caller Profile:** Another attorney or competitor researching

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. How may I help you today?

**Caller:** Hi, yes, I'm interested in learning more about your personal injury practice.

**AI:** I'd be happy to provide information. Are you seeking legal representation for a personal injury matter?

**Caller:** Um, actually I'm an attorney and I'm looking into referring cases. What's your fee structure for personal injury cases?

**AI:** I appreciate your interest in referring cases to our firm. For detailed information about our referral arrangements and fee structures, I'd recommend speaking directly with one of our personal injury attorneys. May I have your name and law firm so we can have an attorney contact you to discuss potential referral arrangements?

**Caller:** Oh, it's okay. I was just gathering some general information.

**AI:** I understand. For general information about our practice, I can share that we handle a full range of personal injury cases including auto accidents, slip and falls, and workplace injuries. We work on a contingency fee basis for most personal injury matters. For specific fee arrangements or referral discussions, one of our attorneys would need to speak with you directly. Would you like me to have someone reach out to you?

**Caller:** No, that's okay. I'll think about it.

**AI:** That's fine. If you'd like to discuss referrals in the future, you can reach out anytime. May I have your name and firm in case you'd like to follow up?

**Caller:** Thanks, I'll call back if I need to.

**AI:** You're welcome. Have a great day.

**AI Decision Points:**
- Identified non-client inquiry
- Remained professional but guarded with detailed information
- Offered appropriate path (attorney-to-attorney discussion)
- Didn't reveal detailed fee structures
- Didn't provide competitive intelligence
- Remained courteous throughout
- Didn't push too hard when caller declined contact

**Outcome:**
- Protected firm's confidential information
- Remained professional with potential referral source
- Didn't waste attorney time on non-prospect

---

## Transfer Scenarios

### Scenario 13: Complex Question Requiring Attorney

**Context:** Business hours  
**Caller Profile:** Question beyond AI's scope

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. How may I help you today?

**Caller:** I have a question about a trust that my mother set up. She passed away last year and I'm trying to figure out if I need to do anything with the trust.

**AI:** I'm sorry for your loss. That's definitely something our estate planning attorney can help you with. However, questions about trust administration involve legal advice, and I'd want you to speak directly with an attorney to make sure you get accurate guidance. Are you able to speak with one of our attorneys now?

**Caller:** Yes, if someone's available.

**AI:** Let me check. May I have your name?

**Caller:** Patricia Morgan.

**AI:** Thank you, Ms. Morgan. Let me see if Attorney Martinez is available to take your call. Please hold for just a moment.

[AI transfers call with context]

**AI (to attorney):** Attorney Martinez, I have Patricia Morgan on the line. Her mother passed away last year and she has questions about trust administration. She needs legal advice that I can't provide.

**Attorney:** Thank you, put her through.

**AI Decision Points:**
- Recognized question requires legal advice
- Did NOT attempt to answer
- Offered immediate transfer instead of just scheduling
- Explained why transfer was needed
- Checked for availability before holding
- Provided context to attorney (warm transfer)

**Outcome:**
- Client spoke with attorney immediately
- Prevented potential misinformation
- Client satisfaction with immediate help

---

### Scenario 14: Caller Requests Specific Attorney

**Context:** Business hours  
**Caller Profile:** Existing client or referral

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. How may I help you today?

**Caller:** Hi, I need to speak with Attorney Williams please.

**AI:** I'd be happy to connect you. May I ask who's calling?

**Caller:** This is Bob Anderson. I'm a client.

**AI:** Thank you, Mr. Anderson. Let me check if Attorney Williams is available. One moment please.

[AI checks availability]

**AI:** Mr. Anderson, Attorney Williams is currently with a client. Would you like me to take a message and have Attorney Williams call you back, or would you like to hold for when they're available?

**Caller:** I'll hold if it won't be too long.

**AI:** Let me check... It looks like Attorney Williams will be available in about 10 minutes. Would you like to hold, or would a callback be better?

**Caller:** I'll hold, thanks.

**AI:** Perfect. I'll put you on hold and Attorney Williams will be with you shortly.

[Transfer to hold queue with information for attorney]

**AI Decision Points:**
- Verified caller identity
- Checked attorney availability before committing
- Provided realistic wait time estimate
- Offered choice between holding and callback
- Set appropriate expectations
- Logged call for attorney context

**Outcome:**
- Client connected to requested attorney
- Professional hold management
- No frustration from unclear wait times

---

## Special Situations

### Scenario 15: Mental Health Crisis Detected

**Context:** Any time  
**Caller Profile:** Person in crisis, potentially suicidal

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. How may I help you today?

**Caller:** [distressed] I need to talk to someone about updating my will. I need to get my affairs in order.

**AI:** I can help you with that. May I ask why you're looking to update your will right now?

**Caller:** Everything is just... I can't take it anymore. I need to make sure my kids are taken care of.

**AI:** I hear that you're going through a very difficult time. Are you thinking about harming yourself?

**Caller:** I don't know... maybe. Everything feels hopeless.

**AI:** I want you to know that there are people who can help you right now. This is an emergency, and I'd like to connect you with someone who specializes in crisis support. Would you be willing to call the National Suicide Prevention Lifeline at 988? They have counselors available 24/7 who can help you right now.

**Caller:** I don't know...

**AI:** Or, if you'd prefer, I can stay on the line with you while we connect you to crisis support. You don't have to go through this alone. Will you let me help you get connected with support?

**Caller:** I guess so.

**AI:** Thank you for letting me help. I'm going to give you the crisis line number: it's 988, or you can text "HELLO" to 741741. Are you in a safe place right now?

**Caller:** I'm at home.

**AI:** Is anyone there with you?

**Caller:** No, I'm alone.

**AI:** Is there someone you trust - a family member or friend - who you could call to be with you right now?

**Caller:** Maybe my sister.

**AI:** I think that would be a good idea. And please call 988 or text 741741 - those counselors are specially trained to help people who are feeling the way you're feeling right now. They can help. Will you do that?

**Caller:** Yes, okay.

**AI:** Good. And if you feel like you might hurt yourself immediately, please call 911. You matter, and there are people who want to help you. Will you call your sister and the crisis line?

**Caller:** Yes, I will.

**AI:** Thank you. Please make those calls right now. And when you're ready, if you do want to speak with an attorney about your estate planning, we'll be here to help you. But right now, please reach out to crisis support.

**[AI immediately flags this call for attorney/manager review and follow-up]**

**AI Decision Points:**
- Recognized potential crisis indicators
- Asked direct suicide screening question
- Prioritized immediate safety over legal services
- Provided specific crisis resources (988, text line)
- Assessed immediate safety situation
- Encouraged personal support network
- Maintained empathy and concern
- Flagged for management review
- Did not attempt to provide legal services in crisis

**Outcome:**
- Crisis resources provided
- Safety prioritized
- Management alerted for potential follow-up
- Potentially life-saving intervention

**Data Captured:**
- Call flagged: MENTAL HEALTH CRISIS
- Crisis resources provided: 988, 741741
- Management notification: Immediate
- Note: Potential client in crisis, prioritized safety over legal services

---

## After-Hours Scenarios

### Scenario 16: Standard After-Hours Call

**Context:** 8 PM on weekday  
**Caller Profile:** Working professional, can only call after work

**Conversation:**

**AI:** Thank you for calling Smith & Associates Law Firm. This is the office assistant. Our office hours are Monday through Friday, 9 AM to 5 PM. However, I'm available 24/7 to help you schedule a consultation or answer general questions about our services. How may I help you?

**Caller:** Oh, I didn't realize it was after hours. I work until 7 and this was my first chance to call.

**AI:** That's completely fine - that's exactly why I'm here. I can help you with scheduling or information about our services. What brings you to call this evening?

**Caller:** I need help with a contract dispute with a vendor. It's a business matter.

**AI:** I understand. We have attorneys who handle business disputes and contract matters. Can I ask a few questions to make sure I connect you with the right attorney?

**Caller:** Sure.

**AI:** Is this related to your business?

**Caller:** Yes, I own a small business and we have a vendor who hasn't delivered on their contract.

**AI:** That's frustrating. Our business law attorneys can review your contract and advise you on your options. Would you like to schedule a consultation?

**Caller:** Yes. Do you have evening appointments? I work until 6 most days.

**AI:** Let me check our schedule. We do have some early morning appointments at 8 AM, and we can occasionally accommodate appointments at 5:30 or 6 PM. Would either of those times work?

**Caller:** An early morning would actually work well for me. I could do 8 AM.

**AI:** Perfect. Let me get your information. Your name?

**[Continues with standard scheduling process]**

**AI Decision Points:**
- Immediately set expectations about office hours
- Explained value of after-hours availability
- Accommodated caller's scheduling needs
- Offered alternative times for working professional
- Didn't make caller feel bad for calling after hours
- Completed full intake and scheduling

**Outcome:**
- After-hours call successfully captured
- Consultation scheduled at time that works for caller
- Demonstrated value of 24/7 availability

---

## Key Patterns & Best Practices

### When AI Handles Independently
- General firm information
- Practice area questions
- Fee range inquiries
- Appointment scheduling
- Basic intake information
- Office hours/location

### When AI Transfers Immediately
- Existing client calls (often)
- Request for specific attorney
- Legal advice needed
- Complex questions beyond scope
- Emergency situations requiring attorney
- Caller insists on speaking to human

### When AI Takes Detailed Message
- Attorney unavailable
- After-hours non-emergency
- Caller prefers callback over scheduling
- Complex matter requiring attorney review before scheduling
- Conflict check needed

### Tone Guidelines by Situation
- **Standard calls:** Professional, friendly, helpful
- **Emotional calls:** Empathetic, patient, supportive
- **Urgent calls:** Calm, efficient, reassuring
- **Angry calls:** Patient, apologetic, solution-focused
- **Crisis calls:** Compassionate, safety-focused, direct

---

**Document Version:** 1.0  
**Last Updated:** October 2025
