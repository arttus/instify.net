--
-- PostgreSQL database dump
--

\restrict hrAdJtGanYoKkdGahKNJyMKaLc0c2hyuDn9BI2fHbsoU3DeEMcAsWQJKQcUwkTP

-- Dumped from database version 16.10 (Debian 16.10-1.pgdg12+1)
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- PostgreSQL database dump complete
--

\unrestrict hrAdJtGanYoKkdGahKNJyMKaLc0c2hyuDn9BI2fHbsoU3DeEMcAsWQJKQcUwkTP

